# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## AgentsEstates MCP (~/workspace/agentsestates/)
- Client: `bin/client.py` (Streamable HTTP via curl subprocess, NOT urllib). Server quirks learned 2026-11-01: WAF 403s Python-urllib user-agent (use a browser UA); urllib responses get truncated (use curl); OMIT `MCP-Protocol-Version` header on `initialize` (server kills the connection); `notifications/initialized` returns HTTP 200, not 202 (treat as OK); server flaps with "World is restarting" / 503s — retry with backoff (5,10,20,30s, max 5 min) per its own mint instructions.
- Auth: POST `/auth/challenge` {"wallet"} → BAW `sign-message preview|execute --signType EIP712` with `{"method":"eth_signTypedData_v4","params":[wallet, typedDataJson]}` → POST `/auth/verify` {"wallet","challenge","signature"} where signature = 64-byte sig + `1b` (v=27). Challenge lives ~300s; verify immediately. Token (1h, often invalidated early by restarts) saved to `.token`, read by the client automatically. Full loop: `signin_loop.py`.
- Facts (chain 56): NFT 0x439643cfd023c247519518B7F73d06823E1F2fCe, mint 0x7ECdCf20A6e7bb10F76f910d01f508395cDa9AD0. Wallet needs .ai Agent ID (registry 0x60B9…022F). Server now allows 3 chars/wallet (1st free, 2nd/3rd 0.00063 BNB).
- Mint flow: `protocol_info` → sign in → ask handle/city/helpers one at a time → `order_house` → poll `build_status` every ~2 min → `mint_transaction` → verify to/chainId/from/value=0 → user approves → send via BAW contract-call. CRITICAL: after `ticketReady`, the character MUST be minted within 60 min (`mintBy`) or the server auto-releases it (house removed, handle freed). Never let the approval wait idle past mintBy.
- `check_build.py` polls build_status and prints only on change (MINT_READY / BUILD_CHECK_AUTH / BUILD_CHECK_ERROR).
- Market (2026-11-01): `prepare_listing` wants `price_bnb` as STRING (number → -32602 invalid). BAW sign-message returns 64-byte sig (no v); server needs 65 bytes — try v=27 ("1b") then v=28 ("1c") on bad_signature (listing needed 1c). market_listings indexer lags several minutes after submit_listing ok:true — re-check before declaring failure.
- BAW pairing reminders: a one-off cron `agentic-wallet-pairing-reminder-2026-11-08` (09:00 WIB check) FAILED to message: "this scheduled job has no chat to message from" — reminder never sent, text had to be handed to resolution. Fix attempted 2026-11-10: the 2026-11-12 reminder cron was created with explicit `delivery` to the main chat (96bdf06d-02dd-4137-8ed5-d15d284bb91b) plus a fallback (hand text to final message if send fails). VERIFIED 2026-11-12: explicit delivery did NOT fix it — both 2026-11-12 jobs (15:51 pre-expiry reminder, 19:05 post-expiry check) again reported "no chat to message from"; the main agent delivered both texts via resolution. So every pairing-reminder cron body must keep the step-5 fallback (hand exact text to the run's final message); never assume the scheduled job itself can message. Pairing sessions last 48h; a reminder ~3h before expiry worked 2026-11-10 (sent 17:09 WIB, user re-paired 18:51 WIB). Never pre-generate a pairing code — codes expire in ~5 min.
